import {
  projects,
  users,
  type Project,
  type UpdateProject,
  type InsertProject,
  type User,
  type UpsertUser,
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";

export interface IStorage {
  // Project operations
  getProject(id: string): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(id: string, updates: UpdateProject): Promise<Project | undefined>;
  deleteProject(id: string): Promise<boolean>;
  getAllProjects(): Promise<Project[]>;
  
  // User operations (required for Replit Auth)  
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUserProjects(userId: string): Promise<Project[]>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // Project operations
  async getProject(id: string): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(eq(projects.id, id));
    return project;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const projectWithDefaults = {
      ...project,
      services: project.services as string[],
    };
    const [newProject] = await db.insert(projects).values(projectWithDefaults).returning();
    return newProject;
  }

  async updateProject(id: string, updates: UpdateProject): Promise<Project | undefined> {
    const updateData = {
      ...updates,
      updatedAt: new Date(),
      ...(updates.services && { services: Array.from(updates.services) })
    };
    const [updatedProject] = await db
      .update(projects)
      .set(updateData)
      .where(eq(projects.id, id))
      .returning();
    return updatedProject;
  }

  async deleteProject(id: string): Promise<boolean> {
    const result = await db.delete(projects).where(eq(projects.id, id));
    return (result.rowCount ?? 0) > 0;
  }

  async getAllProjects(): Promise<Project[]> {
    return db.select().from(projects);
  }

  // User operations (required for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUserProjects(userId: string): Promise<Project[]> {
    // For now, return all projects. In a real implementation, this would filter by user ownership
    return this.getAllProjects();
  }
}

// In-memory storage for demonstration (keeping for fallback)
export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private projects: Map<string, Project>;

  constructor() {
    this.users = new Map();
    this.projects = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const id = userData.id || randomUUID();
    const now = new Date();
    const user: User = {
      id,
      email: userData.email ?? null,
      firstName: userData.firstName ?? null,
      lastName: userData.lastName ?? null,
      profileImageUrl: userData.profileImageUrl ?? null,
      createdAt: now,
      updatedAt: now,
    };
    this.users.set(id, user);
    return user;
  }

  async deleteProject(id: string): Promise<boolean> {
    return this.projects.delete(id);
  }

  async getAllProjects(): Promise<Project[]> {
    return Array.from(this.projects.values());
  }

  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = randomUUID();
    const now = new Date();
    const project: Project = {
      id,
      businessName: insertProject.businessName,
      industry: insertProject.industry,
      services: insertProject.services as string[],
      contactEmail: insertProject.contactEmail,
      contactPhone: insertProject.contactPhone || "",
      address: insertProject.address || "",
      city: insertProject.city || "",
      state: insertProject.state || "",
      description: insertProject.description || "",
      targetAudience: insertProject.targetAudience || "",
      colorScheme: insertProject.colorScheme || "warm",
      contentTone: insertProject.contentTone || "professional",
      status: "pending",
      generatedContent: null,
      generatedImages: null,
      websiteHtml: null,
      createdAt: now,
      updatedAt: now,
    };
    this.projects.set(id, project);
    return project;
  }

  async updateProject(id: string, updates: UpdateProject): Promise<Project | undefined> {
    const project = this.projects.get(id);
    if (!project) return undefined;

    const updatedProject: Project = {
      ...project,
      ...updates,
      updatedAt: new Date(),
      ...(updates.services && { services: Array.from(updates.services) }),
    };
    this.projects.set(id, updatedProject);
    return updatedProject;
  }

  async getUserProjects(userId: string): Promise<Project[]> {
    // In a real implementation, this would filter by user ownership
    return Array.from(this.projects.values());
  }
}

export const storage = new MemStorage();
