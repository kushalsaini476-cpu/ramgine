import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Zap, ShoppingCart, MessageCircle, CreditCard, BarChart3, Palette } from "lucide-react";
import logoImage from "@assets/ChatGPT Image Aug 14, 2025, 01_36_21 PM_1755158797373.png";

export default function Home() {

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="container mx-auto px-6 py-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl flex items-center justify-center">
              <img src={logoImage} alt="Ramgine Logo" className="w-10 h-10 rounded-xl" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">Ramgine</h1>
              <p className="text-sm text-slate-500">E-commerce Platform Builder | Online Store</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs text-slate-500 mb-2">E-commerce Platform</p>
            <p className="text-xs text-slate-400">WhatsApp • UPI • Analytics</p>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-6 py-16 text-center">
        <h2 className="text-4xl md:text-6xl font-bold text-slate-900 mb-6">
          Build Your Online Store
          <span className="text-blue-600"> in Minutes</span>
        </h2>
        <p className="text-xl text-slate-600 mb-8 max-w-3xl mx-auto">
          Create your complete e-commerce store without coding using Ramgine. 
          WhatsApp orders, UPI payments, and order tracking - everything in one place.
        </p>
        <Link href="/onboarding">
          <Button size="lg" className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 px-8 py-4 text-lg">
            Start Building Now
            <Zap className="w-5 h-5 ml-2" />
          </Button>
        </Link>
        <p className="text-sm text-slate-500 mt-4">Completely free to start • No credit card required • WhatsApp orders included</p>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-6 py-16">
        <h3 className="text-3xl font-bold text-center text-slate-900 mb-12">
          Everything You Need for Online Business
        </h3>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-blue-600" />
              </div>
              <CardTitle>AI Store Builder</CardTitle>
              <CardDescription>
                Generate complete online store from your business details in minutes
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <MessageCircle className="w-6 h-6 text-green-600" />
              </div>
              <CardTitle>WhatsApp Orders</CardTitle>
              <CardDescription>
                Customers can order directly via WhatsApp with automatic order management
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <CreditCard className="w-6 h-6 text-purple-600" />
              </div>
              <CardTitle>UPI & Payments</CardTitle>
              <CardDescription>
                UPI, cards, wallets - all payment methods integrated
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                <ShoppingCart className="w-6 h-6 text-orange-600" />
              </div>
              <CardTitle>Order Management</CardTitle>
              <CardDescription>
                Track all orders, manage inventory, customer details
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="w-6 h-6 text-red-600" />
              </div>
              <CardTitle>Analytics & Insights</CardTitle>
              <CardDescription>
                Sales analytics, customer insights, and marketing tools
              </CardDescription>
            </CardHeader>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                <Palette className="w-6 h-6 text-indigo-600" />
              </div>
              <CardTitle>Custom Branding</CardTitle>
              <CardDescription>
                Your logo, colors, and branding for a professional look
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-6 py-16">
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl p-12 text-center text-white">
          <h3 className="text-3xl font-bold mb-4">Ready to Build Your Online Store?</h3>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of small businesses who have increased their sales with WhatsApp orders and UPI payments
          </p>
          <Link href="/onboarding">
            <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-4 text-lg">
              Get Started for Free
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="container mx-auto px-6 py-8 text-center text-slate-500">
        <p>&copy; 2024 Ramgine. All rights reserved.</p>
      </footer>
    </div>
  );
}
